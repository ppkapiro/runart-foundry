# PR Draft — WP Staging Lite — Integración local (Fases B–E)

## Alcance
- MU-plugin `wp-staging-lite` con endpoints REST (`/status`, `/trigger` deshabilitado) y shortcode `[briefing_hub]`.
- Workflows de GitHub Actions:
  - `receive_repository_dispatch.yml` (wp_content_published, rebuild, sync_menus)
  - `post_build_status.yml` (genera docs/status.json post build)
- Validación local con scripts de simulación y evidencia en `docs/ops/logs/`.

Incluye cierre de Fase D (E2E local) y Fase E (seguridad, rollback y paquete de entrega).

## Evidencias
- Endpoints: `GET /wp-json/briefing/v1/status` → 200; `POST /wp-json/briefing/v1/trigger` → 501
- Shortcode (ruta técnica): `/?briefing_hub=1&status_url=http://localhost:10010/wp-json/briefing/v1/status` → render OK
- Workflows (simulados):
  - repo_dispatch → `docs/ops/logs/run_repository_dispatch_*.log`
  - post_build_status → `docs/status.json` y copia en `mu-plugins/wp-staging-lite/status.json`
- Detalle: `docs/integration_wp_staging_lite/TESTS_PLUGIN_LOCAL.md`, `TESTS_WORKFLOWS_LOCAL.md`
- E2E local: `docs/integration_wp_staging_lite/TESTS_E2E_LOCAL.md`

## Seguridad (E1)
- Revisión rápida repo-wide: sin secretos reales. `/trigger` deshabilitado (501). Workflows en modo dry-run.
- Documento: `docs/integration_wp_staging_lite/REVIEW_SEGURIDAD.md` (recomendaciones de hardening incluidas).

## Rollback (E2)
- Procedimiento documentado para retirar plugin y workflows con señales de éxito.
- Documento: `docs/integration_wp_staging_lite/ROLLBACK_PLAN.md`.

## Paquete de entrega (E3)
- ZIP con: MU-plugin, 2 workflows, scripts de simulación/validación y documentación relevante.
- Ruta: `_dist/wp-staging-lite_delivery_<TS>.zip` (ver comentario del PR tras el build local).

## Checklist
- [x] Sin secrets reales
- [x] Reversión simple (eliminar workflows + plugin)
- [x] Documentación y evidencias listas

> Nota: Listo para revisión. Merge gated por aprobación del equipo y pruebas en entorno real (si aplica).

<!-- Actualizado tras completar Fases D y E -->
